import { createContext } from "react";

export const SteperContext = createContext(null)
